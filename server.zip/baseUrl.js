export const baseUrl = "https://marysonthego.tech";
//export const baseUrl = "http://localhost:4000";
//baseUrl points to the server
//import to components
//use in fetch
